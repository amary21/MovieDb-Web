const baseUrl = {
    url_main: "https://api.themoviedb.org/3",
    url_image: "https://image.tmdb.org/t/p/original",
    api_key: "ce3747f9814de0e3fc3292c9ef36fcdb",
    url_dummy:"https://748073e22e8db794416a-cc51ef6b37841580002827d4d94d19b6.ssl.cf3.rackcdn.com/not-found.png"
}

export default baseUrl;